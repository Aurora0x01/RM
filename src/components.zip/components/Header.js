import React from 'react';

const Header = () => {
  return (
    <header className="header">
      <div className="logo">Cafe Flow</div>
      <input type="text" placeholder="Search" className="search-bar" />
      <button className="logout-button">Logout</button>
    </header>
  );
};

export default Header;
