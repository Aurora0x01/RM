import React from 'react';

const ProductList = ({ products, onAddToOrder }) => {
  return (
    <div className="product-list">
      {products.map((product, index) => (
        <div className="product-card" key={index}>
          <img src={product.image} alt={product.name} />
          <h3>{product.name}</h3>
          <p>Prix: {product.price} dt</p>
          <button onClick={() => onAddToOrder(product)}>Add to Order</button>
        </div>
      ))}
    </div>
  );
};

export default ProductList;
